package header

var Name = "Hyperledger Fabric_IoT Project"
var Version = "1.0.0"
var Colors = map[string][]string{
	"@default": {"#4267B2", "#34495E", "#ECF0F1"},
}
var Title = map[string]string{
	"@default": "Hyperledger Fabric_IoT Project",
}
